#include <stdio.h>
#include "fila_prioridade.h"

int main() {
    fila_prioridade fila;
    criar_fila_prioridade(&fila);

    enfileirar(&fila, 9, 2);
    enfileirar(&fila, 6, 1);
    enfileirar(&fila, 78, 3);
    enfileirar(&fila, 100, 2);
    enfileirar(&fila, -3, 1);

    exibir(&fila);

    elemento item_retirado = desenfileirar(&fila);
    printf("removido: (%d, %d)\n", item_retirado.dado, item_retirado.prioridade);

    item_retirado = desenfileirar(&fila);
    printf("desenfileirado: (%d, %d)\n", item_retirado.dado, item_retirado.prioridade);

    return 0;
}
