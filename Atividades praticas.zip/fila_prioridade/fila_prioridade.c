#include "fila_prioridade.h"
#include <stdio.h>
#include <stdlib.h>

void criar_fila_prioridade(fila_prioridade* fila) {
    fila->tamanho = 0;
}

int esta_vazia(fila_prioridade* fila) {
    return (fila->tamanho == 0);
}

int esta_cheia(fila_prioridade* fila) {
    return (fila->tamanho == TAMANHO_MAX);
}

void enfileirar(fila_prioridade* fila, int dado, int prioridade) {
    if (esta_cheia(fila)) {
        printf("A fila de prioridade est� cheia.\n");
        return;
    }

    elemento novo_elemento = {dado, prioridade};
    int i = fila->tamanho;
    while (i > 0 && fila->elementos[i - 1].prioridade <= prioridade) {
        fila->elementos[i] = fila->elementos[i - 1];
        i--;
    }
    fila->elementos[i] = novo_elemento;
    fila->tamanho++;
}

elemento desenfileirar(fila_prioridade* fila) {
    if (esta_vazia(fila)) {
        printf("A fila de prioridade est� vazia.\n");
        exit(EXIT_FAILURE);
    }

    elemento elemento_removido = fila->elementos[0];
    for (int i = 0; i < fila->tamanho - 1; i++) {
        fila->elementos[i] = fila->elementos[i + 1];
    }
    fila->tamanho--;
    return elemento_removido;
}

void exibir(fila_prioridade* fila) {
    if (esta_vazia(fila)) {
        printf("A fila de prioridade est� vazia.\n");
        return;
    }

    printf("Fila de prioridade:\n");
    for (int i = 0; i < fila->tamanho; i++) {
        printf("(%d, %d) ", fila->elementos[i].dado, fila->elementos[i].prioridade);
    }
    printf("\n");
}
