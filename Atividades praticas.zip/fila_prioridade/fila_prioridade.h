#ifndef fila_prioridade_h
#define fila_prioridade_h

#define TAMANHO_MAX 100

typedef struct {
    int dado;
    int prioridade;
} elemento;

typedef struct {
    elemento elementos[TAMANHO_MAX];
    int tamanho;
} fila_prioridade;

void criar_fila_prioridade(fila_prioridade* fila);
int esta_vazia(fila_prioridade* fila);
int esta_cheia(fila_prioridade* fila);
void enfileirar(fila_prioridade* fila, int dado, int prioridade);
elemento desenfileirar(fila_prioridade* fila);
void exibir(fila_prioridade* fila);

#endif /* fila_prioridade_h */
