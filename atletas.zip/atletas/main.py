from atleta import *

if __name__ == "__main__":

    co1 = Corredor("Bolt", 35, 90.5)
    n1 = Nadador("Phleps", 34, 40.4)
    c1 = Ciclista("Fabio", 34, 56.5)
    tri = Triatleta("Fernanda", 23, 45.6)

    print(co1)
    print(co1.aquecer())
    print(co1.correr())
    print(n1)
    print(n1.aquecer())
    print(n1.nadar())
    print(c1)
    print(c1.aquecer())
    print(c1.pedalar())


    print(tri)
    print(tri.realizar_maeratona())
    print(Triatleta.__mro__)


