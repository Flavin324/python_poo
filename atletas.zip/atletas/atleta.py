from abc import ABC

class Atleta(ABC):

    nome : int
    idade : int
    peso : float

    def __init__(self, nome:int, idade:int,peso:float):
     self.nome = nome
     self.idade = idade
     self.peso = peso

    def aquecer(self):
        return  "Aquecendo ..."

    def __str__(self):
        return f'Nome: {self.nome}, {self.idade} anos,{self.peso} Kg'

class Corredor(Atleta):
    def correr(self):
        return "Correndo ..."

class Nadador(Atleta):
    def nadar(self):
        return "Nadar..."

class Ciclista(Atleta):
    def pedalar(self):
        return "Pedalar....."


class Triatleta(Ciclista,Corredor,Nadador):
    def realizar_maeratona(self):
        info = self.aquecer()
        info += self.nadar()
        info += self.pedalar()
        info += self.correr()
        return info